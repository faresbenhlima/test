import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, Pressable, View } from "react-native";
import { Input } from "@ui-kitten/components";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { Color } from "../GlobalStyles";

const LoginPage = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.loginPage}>
      <Image
        style={[styles.imageIkjaIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/imageikja.png")}
      />
      <Input
        style={[styles.inputPassword, styles.inputPosition]}
        placeholder="Passwort"
        placeholderTextColor="#5b5b5b"
        textStyle={styles.inputPasswordTextInputText}
        label="Passwort"
      />
      <Input
        style={[styles.inputUsername, styles.inputPosition]}
        placeholder="Benutzername"
        placeholderTextColor="#5b5b5b"
        textStyle={styles.inputUsernameTextInputText}
        label="Benutzername"
      />
      <Pressable
        style={styles.buttonAnmelden}
        onPress={() => navigation.navigate("RoomsPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/buttonanmelden.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  inputPasswordTextInputText: {
    fontFamily: "Poppins-Regular",
    color: "#5b5b5b",
  },
  inputUsernameTextInputText: {
    fontFamily: "Poppins-Regular",
    color: "#5b5b5b",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  inputPosition: {
    left: "22.14%",
    right: "22.39%",
    width: "55.47%",
    position: "absolute",
  },
  imageIkjaIcon: {
    top: 0,
    right: 0,
    bottom: 604,
    left: 0,
    position: "absolute",
  },
  inputPassword: {
    top: "78.4%",
    bottom: "17.25%",
  },
  inputUsername: {
    top: "70.19%",
    bottom: "25.47%",
  },
  icon: {
    height: "100%",
    width: "100%",
    maxWidth: "100%",
  },
  buttonAnmelden: {
    left: "47.33%",
    top: "94.18%",
    right: "47.63%",
    bottom: "3.97%",
    width: "5.04%",
    height: "1.85%",
    position: "absolute",
  },
  loginPage: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default LoginPage;
