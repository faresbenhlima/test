import * as React from "react";
import { StyleSheet, View, Text, Pressable } from "react-native";
import { Image } from "expo-image";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontFamily, FontSize, Color } from "../GlobalStyles";

const ChatPageAnonym = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.chatPageAnonym}>
      <View style={styles.inputMessage}>
        <View style={[styles.rectMessage, styles.rectMessagePosition]} />
        <Text style={[styles.youCanNot, styles.youCanNotPosition]}>
          You can not reply to this message.
        </Text>
      </View>
      <Pressable
        style={styles.buttonBack}
        onPress={() => navigation.navigate("RoomsPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/buttonback.png")}
        />
      </Pressable>
      <View style={styles.room1}>
        <Text style={[styles.a2DeutschSprachkurs, styles.youCanNotPosition]}>
          A2 Deutsch Sprachkurs
        </Text>
        <Image
          style={[styles.logoChatIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/logochat.png")}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  rectMessagePosition: {
    left: 0,
    bottom: 0,
    top: 0,
    position: "absolute",
  },
  youCanNotPosition: {
    textAlign: "left",
    top: 14,
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  rectMessage: {
    right: 0,
    borderRadius: 43,
    backgroundColor: "#ecf0f0",
  },
  youCanNot: {
    left: 14,
    fontSize: 13,
    lineHeight: 20,
    fontFamily: FontFamily.poppinsRegular,
    color: "#5b5b5b",
    width: 251,
    height: 21,
  },
  inputMessage: {
    height: "5.63%",
    width: "81.42%",
    top: "87.68%",
    right: "9.41%",
    bottom: "6.69%",
    left: "9.16%",
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
    maxHeight: "100%",
    maxWidth: "100%",
  },
  buttonBack: {
    left: "4.07%",
    top: "5.87%",
    right: "93.21%",
    bottom: "91.94%",
    width: "2.72%",
    height: "2.19%",
    position: "absolute",
  },
  a2DeutschSprachkurs: {
    left: 71,
    fontSize: FontSize.size_mini,
    lineHeight: 18,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorBlack,
  },
  logoChatIcon: {
    right: 200,
    left: 0,
    bottom: 0,
    top: 0,
    position: "absolute",
  },
  room1: {
    marginTop: -390,
    marginLeft: -138.5,
    top: "50%",
    left: "50%",
    width: 246,
    height: 46,
    position: "absolute",
  },
  chatPageAnonym: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default ChatPageAnonym;
