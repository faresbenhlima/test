import * as React from "react";
import { Text, StyleSheet, View, Pressable } from "react-native";
import { Image } from "expo-image";
import { Input as RNEInput } from "@rneui/themed";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const RoomsPage = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.roomsPage}>
      <Pressable
        style={[styles.room1, styles.roomPosition]}
        onPress={() => navigation.navigate("ChatPageAnonym")}
      >
        <Text style={styles.a2DeutschSprachkurs}>A2 Deutsch Sprachkurs</Text>
        <Image
          style={[styles.logoChatIcon, styles.logoIconPosition]}
          contentFit="cover"
          source={require("../assets/logochat.png")}
        />
      </Pressable>
      <Pressable
        style={[styles.room2, styles.roomPosition]}
        onPress={() => navigation.navigate("ChatPageNormal")}
      >
        <Text style={styles.a2DeutschSprachkurs}>{`Theresa `}</Text>
        <Image
          style={[styles.logoChatIcon1, styles.logoIconPosition]}
          contentFit="cover"
          source={require("../assets/logochat.png")}
        />
      </Pressable>
      <RNEInput
        value="Search Chat"
        inputStyle={{ color: "#595f67" }}
        containerStyle={styles.inputSearchTextInputInput}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  inputSearchTextInputInput: {
    left: "4.58%",
    right: "13.99%",
    width: "81.42%",
    height: "5.63%",
    top: "6.92%",
    bottom: "87.44%",
    position: "absolute",
  },
  roomPosition: {
    height: 46,
    left: "50%",
    top: "50%",
    marginLeft: -176.5,
    position: "absolute",
  },
  logoIconPosition: {
    maxHeight: "100%",
    maxWidth: "100%",
    left: 0,
    bottom: 0,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  a2DeutschSprachkurs: {
    top: 14,
    left: 71,
    fontSize: FontSize.size_mini,
    lineHeight: 18,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorBlack,
    textAlign: "left",
    position: "absolute",
  },
  logoChatIcon: {
    right: 200,
  },
  room1: {
    marginTop: -185,
    width: 246,
  },
  logoChatIcon1: {
    right: 86,
  },
  room2: {
    marginTop: -100,
    width: 132,
  },
  roomsPage: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    width: "100%",
    height: 852,
    overflow: "hidden",
  },
});

export default RoomsPage;
