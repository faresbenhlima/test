import * as React from "react";
import { Image } from "expo-image";
import { StyleSheet, Text, View, Pressable } from "react-native";
import { Input as RNEInput } from "@rneui/themed";
import { StackNavigationProp } from "@react-navigation/stack";
import { useNavigation, ParamListBase } from "@react-navigation/native";
import { FontSize, FontFamily, Color } from "../GlobalStyles";

const ChatPageNormal = () => {
  const navigation = useNavigation<StackNavigationProp<ParamListBase>>();

  return (
    <View style={styles.chatPageNormal}>
      <Image
        style={[styles.buttonUploadIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/buttonupload.png")}
      />
      <Image
        style={[styles.buttonSendIcon, styles.iconLayout]}
        contentFit="cover"
        source={require("../assets/buttonsend.png")}
      />
      <RNEInput
        value="Start typing..."
        inputStyle={{ color: "#5b5b5b" }}
        containerStyle={styles.inputMessageTextInputInput}
      />
      <View style={styles.room2}>
        <Text style={styles.theresa}>{`Theresa `}</Text>
        <Image
          style={[styles.logoChatIcon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/logochat.png")}
        />
      </View>
      <Pressable
        style={styles.buttonBack}
        onPress={() => navigation.navigate("RoomsPage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          contentFit="cover"
          source={require("../assets/buttonback.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  inputMessageTextInputInput: {
    left: "8.47%",
    right: "10.1%",
    width: "81.42%",
    height: "5.63%",
    top: "88.5%",
    bottom: "5.87%",
    position: "absolute",
  },
  iconLayout: {
    maxHeight: "100%",
    maxWidth: "100%",
    overflow: "hidden",
  },
  buttonUploadIcon: {
    height: "2.16%",
    width: "4.17%",
    top: "90.33%",
    right: "93.72%",
    bottom: "7.51%",
    left: "2.11%",
    position: "absolute",
  },
  buttonSendIcon: {
    height: "2.25%",
    width: "4.78%",
    top: "90.26%",
    right: "1.83%",
    bottom: "7.49%",
    left: "93.38%",
    position: "absolute",
  },
  theresa: {
    top: 14,
    left: 71,
    fontSize: FontSize.size_mini,
    lineHeight: 18,
    fontWeight: "500",
    fontFamily: FontFamily.poppinsMedium,
    color: Color.colorBlack,
    textAlign: "left",
    position: "absolute",
  },
  logoChatIcon: {
    top: 0,
    right: 86,
    bottom: 0,
    left: 0,
    position: "absolute",
  },
  room2: {
    marginTop: -390,
    marginLeft: -135.5,
    top: "50%",
    left: "50%",
    width: 132,
    height: 46,
    position: "absolute",
  },
  icon: {
    height: "100%",
    width: "100%",
    maxWidth: "100%",
  },
  buttonBack: {
    left: "4.07%",
    top: "5.87%",
    right: "93.21%",
    bottom: "91.94%",
    width: "2.72%",
    height: "2.19%",
    position: "absolute",
  },
  chatPageNormal: {
    backgroundColor: Color.colorWhite,
    flex: 1,
    height: 852,
    overflow: "hidden",
    width: "100%",
  },
});

export default ChatPageNormal;
