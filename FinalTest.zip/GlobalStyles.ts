/* fonts */
export const FontFamily = {
  poppinsMedium: "Poppins-Medium",
  poppinsRegular: "Poppins-Regular",
};
/* font sizes */
export const FontSize = {
  size_mini: 15,
};
/* Colors */
export const Color = {
  colorWhite: "#fff",
  colorBlack: "#000",
};
