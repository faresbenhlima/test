import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import IPhone1415Pro1 from "./pages/IPhone1415Pro1";
import Home from "./pages/Home";
import ChatScreen2 from "./pages/ChatScreen2";
import ChatScreen1 from "./pages/ChatScreen1";
import ChatScreenLocked from "./pages/ChatScreenLocked";
import ChatScreen4 from "./pages/ChatScreen4";
import ChatScreen3 from "./pages/ChatScreen3";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/home":
        title = "";
        metaDescription = "";
        break;
      case "/chat-screen-2":
        title = "";
        metaDescription = "";
        break;
      case "/chat-screen-1":
        title = "";
        metaDescription = "";
        break;
      case "/chat-screen-locked":
        title = "";
        metaDescription = "";
        break;
      case "/chat-screen-4":
        title = "";
        metaDescription = "";
        break;
      case "/chat-screen-3":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<IPhone1415Pro1 />} />
      <Route path="/home" element={<Home />} />
      <Route path="/chat-screen-2" element={<ChatScreen2 />} />
      <Route path="/chat-screen-1" element={<ChatScreen1 />} />
      <Route path="/chat-screen-locked" element={<ChatScreenLocked />} />
      <Route path="/chat-screen-4" element={<ChatScreen4 />} />
      <Route path="/chat-screen-3" element={<ChatScreen3 />} />
    </Routes>
  );
}
export default App;
