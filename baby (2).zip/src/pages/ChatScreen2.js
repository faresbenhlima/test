import { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./ChatScreen2.css";

const ChatScreen2 = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  const onSetting2Click = useCallback(() => {
    navigate("/chat-screen-3");
  }, [navigate]);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onMenuBarContainerClick = useCallback(() => {
    navigate("/chat-screen-1");
  }, [navigate]);

  const onArhiveExportClick = useCallback(() => {
    navigate("/chat-screen-1");
  }, [navigate]);

  return (
    <div className="chat-screen-2">
      <div className="frame-group">
        <img className="frame-child2" alt="" src="/frame-41.svg" />
        <div className="my-carbon-footprint">My carbon footprint</div>
      </div>
      <div className="frame11">
        <div className="frame12">
          <div className="frame13">
            <button
              className="chevron-left-wrapper"
              onClick={onFrameButtonClick}
            >
              <img
                className="chevron-left-icon"
                alt=""
                src="/chevronleft.svg"
              />
            </button>
            <div className="frame14">
              <div className="avatar-parent2">
                <div className="avatar5">
                  <div className="src6">{` `}</div>
                  <div className="name6">TA</div>
                  <img className="image-icon5" alt="" src="/image1@2x.png" />
                  <div className="avatarbadge7" />
                </div>
                <div className="frame15">
                  <div className="theresa1">{`Theresa `}</div>
                </div>
              </div>
              <button className="arhive-export" onClick={onSetting2Click}>
                <img
                  className="vuesaxlinearsetting-2-icon"
                  alt=""
                  src="/vuesaxlinearsetting2.svg"
                />
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="frame16">
        <div className="frame17">
          <div className="frame18" />
          <div className="frame19" data-animate-on-scroll>
            <div className="frame-container">
              <button className="frame-wrapper">
                <div className="vuesaxlineardocument-parent">
                  <img
                    className="vuesaxlineardocument-icon1"
                    alt=""
                    src="/vuesaxlineardocument1.svg"
                  />
                  <div className="send-file"> Send File</div>
                </div>
              </button>
              <button className="frame-button">
                <div className="vuesaxlineargallery-export-parent">
                  <img
                    className="vuesaxlineardocument-icon1"
                    alt=""
                    src="/vuesaxlineargalleryexport.svg"
                  />
                  <div className="send-a-picture"> Send a Picture</div>
                </div>
              </button>
              <img className="frame-icon1" alt="" src="/frame1.svg" />
            </div>
          </div>
        </div>
        <div className="frame20">
          <div className="menu-bar" onClick={onMenuBarContainerClick}>
            <button className="arhive-export" onClick={onArhiveExportClick}>
              <img
                className="arhive-export-child"
                alt=""
                src="/rectangle-2.svg"
              />
              <img
                className="arhive-export-item"
                alt=""
                src="/rectangle-1.svg"
              />
              <img className="arhive-export-inner" alt="" src="/vector-9.svg" />
            </button>
            <input
              className="menu-bar-child"
              placeholder="Start typing..."
              type="text"
            />
            <button className="paperplaneright">
              <img
                className="vuesaxlinearsetting-2-icon"
                alt=""
                src="/vector.svg"
              />
              <img className="vector-icon1" alt="" src="/vector1.svg" />
            </button>
          </div>
          <div className="homeindicator2">
            <div className="home-indicator3" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatScreen2;
