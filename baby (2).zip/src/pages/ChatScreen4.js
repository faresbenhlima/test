import { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./ChatScreen4.css";

const ChatScreen4 = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  const onArhiveExportClick = useCallback(() => {
    navigate("/chat-screen-2");
  }, [navigate]);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onSetting2Click = useCallback(() => {
    navigate("/chat-screen-1");
  }, [navigate]);

  return (
    <div className="chat-screen-4">
      <div className="my-carbon-footprint-container">
        <div className="my-carbon-footprint3">My carbon footprint</div>
        <img className="frame-child6" alt="" src="/frame-41.svg" />
      </div>
      <div className="homeindicator5">
        <div className="home-indicator6" />
      </div>
      <div className="chat-screen-4-child" />
      <button className="chevron-left-wrapper1" onClick={onFrameButtonClick}>
        <img className="chevron-left-icon3" alt="" src="/chevronleft.svg" />
      </button>
      <div className="chat-screen-4-item" />
      <div className="avatar-parent4">
        <div className="avatar7">
          <div className="src8">{` `}</div>
          <div className="name8">TA</div>
          <img className="image-icon7" alt="" src="/image5@2x.png" />
          <div className="avatarbadge9" />
        </div>
        <div className="theresa3">{`Theresa `}</div>
      </div>
      <div className="menu-bar3">
        <button className="arhive-export2" onClick={onArhiveExportClick}>
          <img className="arhive-export-child3" alt="" src="/rectangle-2.svg" />
          <img className="arhive-export-child4" alt="" src="/rectangle-1.svg" />
          <img className="arhive-export-child5" alt="" src="/vector-9.svg" />
        </button>
        <input
          className="menu-bar-inner"
          placeholder="Start typing..."
          type="text"
        />
        <button className="paperplaneright2">
          <img className="vector-icon4" alt="" src="/vector.svg" />
          <img className="vector-icon5" alt="" src="/vector1.svg" />
        </button>
      </div>
      <div className="chat">
        <div className="today">Today</div>
        <div className="chat-inner" data-animate-on-scroll>
          <div className="frame-parent1">
            <button className="wrapper">
              <div className="french">{`عربي `}</div>
            </button>
            <button className="wrapper">
              <div className="french">українська</div>
            </button>
            <button className="wrapper">
              <div className="french">Русский</div>
            </button>
            <button className="wrapper">
              <div className="french">فارسی</div>
            </button>
            <button className="wrapper">
              <div className="french">French</div>
            </button>
            <button className="wrapper">
              <div className="kurd">Kurdî</div>
            </button>
          </div>
        </div>
      </div>
      <button className="setting-23" onClick={onSetting2Click}>
        <img className="vector-icon4" alt="" src="/vuesaxlinearsetting2.svg" />
      </button>
    </div>
  );
};

export default ChatScreen4;
