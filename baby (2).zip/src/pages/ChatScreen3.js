import { useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./ChatScreen3.css";

const ChatScreen3 = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  const onArhiveExportClick = useCallback(() => {
    navigate("/chat-screen-2");
  }, [navigate]);

  const onSetting2Click = useCallback(() => {
    navigate("/chat-screen-1");
  }, [navigate]);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add("animate");
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  const onFrameButton2Click = useCallback(() => {
    navigate("/chat-screen-4");
  }, [navigate]);

  return (
    <div className="chat-screen-3">
      <div className="my-carbon-footprint-parent1">
        <div className="my-carbon-footprint4">My carbon footprint</div>
        <img className="frame-child7" alt="" src="/frame-41.svg" />
      </div>
      <div className="homeindicator6">
        <div className="home-indicator7" />
      </div>
      <div className="chat-screen-3-child" />
      <button className="chevron-left-wrapper2" onClick={onFrameButtonClick}>
        <img className="chevron-left-icon4" alt="" src="/chevronleft.svg" />
      </button>
      <div className="chat-screen-3-item" />
      <div className="avatar-parent5">
        <div className="avatar8">
          <div className="src9">{` `}</div>
          <div className="name9">TA</div>
          <img className="image-icon8" alt="" src="/image5@2x.png" />
          <div className="avatarbadge10" />
        </div>
        <div className="theresa4">{`Theresa `}</div>
      </div>
      <div className="menu-bar4">
        <button className="arhive-export3" onClick={onArhiveExportClick}>
          <img className="arhive-export-child6" alt="" src="/rectangle-2.svg" />
          <img className="arhive-export-child7" alt="" src="/rectangle-1.svg" />
          <img className="arhive-export-child8" alt="" src="/vector-9.svg" />
        </button>
        <input
          className="menu-bar-child1"
          placeholder="Start typing..."
          type="text"
        />
        <button className="paperplaneright3">
          <img className="vector-icon6" alt="" src="/vector.svg" />
          <img className="vector-icon7" alt="" src="/vector1.svg" />
        </button>
      </div>
      <button className="setting-24" onClick={onSetting2Click}>
        <img className="vector-icon6" alt="" src="/vuesaxlinearsetting2.svg" />
      </button>
      <div className="frame-parent2" data-animate-on-scroll>
        <button className="others-parent">
          <div className="others">Others</div>
          <img className="info-icon" alt="" src="/info.svg" />
        </button>
        <button
          className="change-language-parent"
          onClick={onFrameButton2Click}
        >
          <div className="change-language">Change Language</div>
          <img
            className="horizontal-switch-icon"
            alt=""
            src="/horizontal-switch.svg"
          />
        </button>
      </div>
    </div>
  );
};

export default ChatScreen3;
