import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./ChatScreenLocked.css";

const ChatScreenLocked = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  return (
    <div className="chat-screen-locked">
      <div className="my-carbon-footprint-group">
        <div className="my-carbon-footprint2">My carbon footprint</div>
        <img className="frame-child4" alt="" src="/frame-41.svg" />
      </div>
      <div className="homeindicator4">
        <div className="home-indicator5" />
      </div>
      <div className="chat-screen-locked-child" />
      <button className="chevron-left-frame" onClick={onFrameButtonClick}>
        <img className="chevron-left-icon2" alt="" src="/chevronleft.svg" />
      </button>
      <div className="chat-screen-locked-item" />
      <div className="a2-deutsch-sprachkurs-parent">
        <div className="a2-deutsch-sprachkurs1">{`A2 Deutsch Sprachkurs `}</div>
        <div className="pngtreebusiness-logo-design-f1" />
        <img
          className="pngtreebusiness-logo-design-f2"
          alt=""
          src="/pngtreebusiness-logo-design-free-logo-915991-2@2x.png"
        />
      </div>
      <div className="menu-bar2">
        <div className="rectangle-group">
          <div className="frame-child5" />
          <div className="you-can-not">You can not reply to this message.</div>
        </div>
      </div>
      <button className="setting-22">
        <img
          className="vuesaxlinearsetting-2-icon2"
          alt=""
          src="/vuesaxlinearsetting2.svg"
        />
      </button>
      <img className="lock-icon" alt="" src="/lock.svg" />
    </div>
  );
};

export default ChatScreenLocked;
