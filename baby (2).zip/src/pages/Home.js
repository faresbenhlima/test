import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./Home.css";

const Home = () => {
  const navigate = useNavigate();

  const onChat5ContainerClick = useCallback(() => {
    navigate("/chat-screen-locked");
  }, [navigate]);

  const onChat03ContainerClick = useCallback(() => {
    navigate("/chat-screen-1");
  }, [navigate]);

  return (
    <div className="home">
      <div className="text-parent">
        <div className="text">My carbon footprint</div>
        <img className="frame-child1" alt="" src="/frame-41.svg" />
      </div>
      <div className="frame6">
        <div className="homeindicator">
          <div className="home-indicator1" />
        </div>
        <div className="rectangle-div" />
        <div className="homeindicator1">
          <div className="home-indicator1" />
        </div>
        <div className="chat-5-parent">
          <div className="chat-5" onClick={onChat5ContainerClick}>
            <button className="chat-5-child" />
            <div className="avatar-parent">
              <div className="avatar">
                <div className="src1">{` `}</div>
                <div className="name1">TA</div>
                <img
                  className="rounded-rectangle-icon"
                  alt=""
                  src="/rounded-rectangle@2x.png"
                />
                <div className="avatarbadge1" />
              </div>
              <button className="pngtreebusiness-logo-design-f" />
              <div className="avatarbadge2" />
              <div className="a2-deutsch-sprachkurs">A2 Deutsch Sprachkurs</div>
              <div className="yesterday-parent">
                <div className="yesterday">Yesterday</div>
                <div className="read-1" />
              </div>
            </div>
          </div>
          <div className="chat-03" onClick={onChat03ContainerClick}>
            <button className="chat-03-child" />
            <div className="avatar-group">
              <button className="avatar1">
                <div className="src2">{` `}</div>
                <div className="name2">TA</div>
                <img className="image-icon1" alt="" src="/image1@2x.png" />
                <div className="avatarbadge1" />
              </button>
              <div className="ellipse-parent">
                <div className="ellipse-div" />
                <div className="div">06.21</div>
                <div className="div1">1</div>
              </div>
              <div className="okay-ill-work-on-it-when-it-parent">
                <div className="okay-ill-work">
                  Okay, i’ll work on it when it’s...
                </div>
                <div className="theresa">{`Theresa `}</div>
              </div>
            </div>
          </div>
          <div className="chat-8">
            <button className="chat-03-child" />
            <div className="avatar-group">
              <button className="avatar1">
                <div className="src2">{` `}</div>
                <div className="name2">TA</div>
                <img className="image-icon1" alt="" src="/image2@2x.png" />
                <div className="avatarbadge1" />
              </button>
              <div className="okay-its-all-noted-parent">
                <div className="okay-ill-work">Okay, it’s all noted.</div>
                <div className="theresa">{`Eleanor `}</div>
              </div>
              <div className="yesterday-parent">
                <div className="yesterday">Yesterday</div>
                <div className="read-1" />
              </div>
            </div>
          </div>
          <div className="chat-8">
            <button className="chat-03-child" />
            <div className="avatar-group">
              <button className="avatar1">
                <div className="src2">{` `}</div>
                <div className="name2">TA</div>
                <img className="image-icon1" alt="" src="/image3@2x.png" />
                <div className="avatarbadge1" />
              </button>
              <div className="okay-its-all-noted-parent">
                <div className="okay-ill-work">Okay, it’s all noted.</div>
                <div className="theresa">{`Kathryn `}</div>
              </div>
              <div className="yesterday2">Yesterday</div>
            </div>
          </div>
          <div className="chat-8">
            <button className="chat-03-child" />
            <div className="avatar-group">
              <button className="avatar1">
                <div className="src2">{` `}</div>
                <div className="name2">TA</div>
                <img className="image-icon1" alt="" src="/image4@2x.png" />
                <div className="avatarbadge1" />
              </button>
              <div className="okay-its-all-noted-parent">
                <div className="okay-ill-work">Okay, it’s all noted.</div>
                <div className="theresa">{`Wade `}</div>
              </div>
              <div className="yesterday2">Yesterday</div>
            </div>
          </div>
        </div>
      </div>
      <div className="frame7">
        <div className="frame8">
          <div className="frame9">
            <button className="hioutlinemenu-wrapper">
              <button className="hioutlinemenu">
                <img
                  className="vector-stroke-icon"
                  alt=""
                  src="/vector-stroke.svg"
                />
              </button>
            </button>
            <button className="fiedit-wrapper">
              <button className="fiedit">
                <img
                  className="vector-stroke-icon1"
                  alt=""
                  src="/vector-stroke1.svg"
                />
                <img
                  className="vector-stroke-icon2"
                  alt=""
                  src="/vector-stroke2.svg"
                />
              </button>
            </button>
          </div>
        </div>
        <div className="frame10">
          <input className="search-bar" placeholder="Search Chat" type="text" />
        </div>
      </div>
    </div>
  );
};

export default Home;
