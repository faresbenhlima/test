import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./IPhone1415Pro1.css";

const IPhone1415Pro1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onSignInSqureClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  return (
    <div className="iphone-14-15-pro-1">
      <div className="frame">
        <div className="frame-child" />
        <img className="ikja-1-icon" alt="" src="/ikja-1@2x.png" />
      </div>
      <div className="frame1">
        <div className="frame2">
          <b className="think-different-think-one-container">
            <span className="think-different-think-one-container1">
              <p className="think-different">THINK DIFFERENT</p>
              <p className="think-different">THINK ONE WORLD</p>
            </span>
          </b>
        </div>
        <div className="frame3">
          <button className="sign-in-squre" onClick={onSignInSqureClick}>
            <img
              className="sign-in-squre-child"
              alt=""
              src="/rectangle-21.svg"
            />
            <img className="sign-in-squre-item" alt="" src="/vector-91.svg" />
          </button>
        </div>
        <div className="frame4">
          <div className="rectangle-parent">
            <button className="frame-item" />
            <div className="frame-inner" />
            <img className="user-box-icon" alt="" src="/user-box.svg" />
            <input className="frame-input" type="text" />
            <input
              className="benutzer123"
              placeholder="benutzer123"
              type="text"
            />
          </div>
          <div className="frame-parent">
            <img className="frame-icon" alt="" src="/frame.svg" />
            <div className="frame5">
              <input className="rectangle-input" type="text" />
              <b className="b">**********</b>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default IPhone1415Pro1;
