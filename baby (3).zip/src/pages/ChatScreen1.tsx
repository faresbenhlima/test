import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./ChatScreen1.css";

const ChatScreen1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/home");
  }, [navigate]);

  const onSetting2Click = useCallback(() => {
    navigate("/chat-screen-3");
  }, [navigate]);

  const onArhiveExportClick = useCallback(() => {
    navigate("/chat-screen-2");
  }, [navigate]);

  return (
    <div className="chat-screen-1">
      <div className="my-carbon-footprint-parent">
        <div className="my-carbon-footprint1">My carbon footprint</div>
        <img className="frame-child3" alt="" src="/frame-41.svg" />
      </div>
      <div className="frame21">
        <div className="frame22">
          <button
            className="chevron-left-container"
            onClick={onFrameButtonClick}
          >
            <img className="chevron-left-icon1" alt="" src="/chevronleft.svg" />
          </button>
          <div className="frame23">
            <div className="avatar-parent3">
              <div className="avatar6">
                <div className="src7">{` `}</div>
                <div className="name7">TA</div>
                <img className="image-icon6" alt="" src="/image5@2x.png" />
                <div className="avatarbadge8" />
              </div>
              <div className="theresa2">{`Theresa `}</div>
            </div>
            <button className="setting-21" onClick={onSetting2Click}>
              <img
                className="vuesaxlinearsetting-2-icon1"
                alt=""
                src="/vuesaxlinearsetting2.svg"
              />
            </button>
          </div>
        </div>
      </div>
      <div className="frame24">
        <div className="frame25">
          <div className="homeindicator3">
            <div className="home-indicator4" />
          </div>
          <div className="menu-bar1">
            <button className="arhive-export1" onClick={onArhiveExportClick}>
              <img className="rectangle-icon" alt="" src="/rectangle-2.svg" />
              <img
                className="arhive-export-child1"
                alt=""
                src="/rectangle-1.svg"
              />
              <img
                className="arhive-export-child2"
                alt=""
                src="/vector-9.svg"
              />
            </button>
            <input
              className="menu-bar-item"
              placeholder="Start typing..."
              type="text"
            />
            <button className="paperplaneright1">
              <img
                className="vuesaxlinearsetting-2-icon1"
                alt=""
                src="/vector.svg"
              />
              <img className="vector-icon3" alt="" src="/vector1.svg" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatScreen1;
